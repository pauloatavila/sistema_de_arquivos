
package bdemtxt;

public class UnidadeMedida implements java.io.Serializable{
    String abrev;
    String nome;
    
    UnidadeMedida(String abv, String name){
        abrev = abv;
        nome = name;
    }
}
