
package bdemtxt;


public class Produtos implements java.io.Serializable{
    int indice;
    String desc;
    String qntd;
    String prec;
    String unM;
    
    Produtos(int id, String descricao, String quantidade, String preco, String medida){
        indice = id;
        desc = descricao;
        qntd = quantidade;
        prec = preco;
        unM = medida;
    }
}
